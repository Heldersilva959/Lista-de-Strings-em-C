#include <stdio.h>
#include <string.h>

#define MAX_FRASE 350

int contarPalavras(char *frase) {
	int i, contagem = 0;
	int tamanho = strlen(frase);
	int estado = 0; // 0 - fora de palavra, 1 - dentro de palavra

	for (i = 0; i < tamanho; i++) {
    	if (frase[i] == ' ' || frase[i] == '\t' || frase[i] == '\n') {
        	estado = 0;
    	} else if (estado == 0) {
        	estado = 1;
        	contagem++;
    	}
	}

	return contagem;
}

int main() {
	char frase[MAX_FRASE];
	printf("Digite uma frase (com até %d caracteres):\n", MAX_FRASE);
	fgets(frase, MAX_FRASE, stdin);

	int numPalavras = contarPalavras(frase);
	printf("A frase tem %d palavra(s).\n", numPalavras);

	return 0;
}
