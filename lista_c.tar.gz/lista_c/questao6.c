#include <stdio.h>
#include <string.h>

#define MAX_NOME 100
#define MAX_SOBRENOME 20

void construirNovaString(char *nomeCompleto, char *novaString) {
    char *token;
    char sobrenomeAbrev[MAX_SOBRENOME];

    // Obtém o primeiro nome
    token = strtok(nomeCompleto, " ");
    strcpy(novaString, token);
    strcat(novaString, " ");

    // Obtém os sobrenomes e os abrevia
    while ((token = strtok(NULL, " ")) != NULL) {
        strncpy(sobrenomeAbrev, token, 1);
        sobrenomeAbrev[1] = '.';
        sobrenomeAbrev[2] = '\0';
        strcat(novaString, sobrenomeAbrev);
        strcat(novaString, " ");
    }

    novaString[strlen(novaString) - 1] = '\0'; // Remove o último espaço
}

int main() {
    char nomeCompleto[MAX_NOME];
    char novaString[MAX_NOME];

    printf("Digite o nome completo do aluno: ");
    fgets(nomeCompleto, MAX_NOME, stdin);
    nomeCompleto[strcspn(nomeCompleto, "\n")] = '\0'; // Remove o caractere de nova linha

    construirNovaString(nomeCompleto, novaString);

    printf("Nova string: %s\n", novaString);

    return 0;
}
