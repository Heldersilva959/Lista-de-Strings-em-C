#include <stdio.h>
#include <string.h>

#define MAX_FRASE 100

void inverterFrase(char *frase, char *fraseInvertida) {
    int i, j;
    int tamanho = strlen(frase);

    // Copiar os caracteres da frase original em ordem invertida para a frase invertida
    for (i = tamanho - 1, j = 0; i >= 0; i--, j++) {
        fraseInvertida[j] = frase[i];
    }
    fraseInvertida[j] = '\0';
}

int main() {
    char frase[MAX_FRASE];
    char fraseInvertida[MAX_FRASE];

    printf("Digite uma frase: ");
    fgets(frase, MAX_FRASE, stdin);

    inverterFrase(frase, fraseInvertida);

    printf("Frase original: %s", frase);
    printf("Frase invertida: %s", fraseInvertida);

    return 0;
}
