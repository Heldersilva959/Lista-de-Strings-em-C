#include <stdio.h>
#include <string.h>

#define MAX_TAMANHO 100

void removerEspacos(char *vetor, char *novaString) {
    int i, j = 0;
    int tamanho = strlen(vetor);

    for (i = 0; i < tamanho; i++) {
        if (vetor[i] != ' ') {
            novaString[j] = vetor[i];
            j++;
        }
    }

    novaString[j] = '\0';
}

int main() {
    char vetor[MAX_TAMANHO];
    char novaString[MAX_TAMANHO];

    printf("Digite uma frase espaçada: ");
    fgets(vetor, MAX_TAMANHO, stdin);

    removerEspacos(vetor, novaString);

    printf("Nova string: %s\n", novaString);

    return 0;
}
