#include <stdio.h>
#include <string.h>

void removeCaracteresRepetidos(char *string) {
	int tamanho = strlen(string);
	int i, j, k;

	for (i = 0; i < tamanho; i++) {
    	if (string[i] != '\0') {
        	for (j = i + 1; j < tamanho; j++) {
            	if (string[j] == string[i]) {
                	for (k = j; k < tamanho; k++) {
                    	string[k] = string[k + 1];
                	}
                	tamanho--;
                	j--;
            	}
        	}
    	}
	}
}

int main() {
	char texto[] = "Hello, World!";
	printf("Texto original: %s\n", texto);

	removeCaracteresRepetidos(texto);

	printf("Texto sem caracteres repetidos: %s\n", texto);

	return 0;
}
