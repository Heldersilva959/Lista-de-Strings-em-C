#include <stdio.h>
#include <ctype.h>

void converterParaMinusculas(char *string) {
    int i = 0;
    while (string[i]) {
        string[i] = tolower(string[i]);
        i++;
    }
}

int main() {
    printf("texto original: OLA, MUNDO! \n");
    printf("texto minusculo:  ");
    
    char texto[] = "OLA, MUNDO!";
    converterParaMinusculas(texto);
    printf("%s", texto);
    
    return 0;
}

